//Create a mouse object that has four properties and three methods
