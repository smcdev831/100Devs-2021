//create a function that adds two numbers and alerts the sum

function addTwoNumbers(num1, num2){
  let sum = num1 + num2
  alert(sum)
}
addTwoNumbers(2,3)
addTwoNumbers(10,22)
//create a function that multiplys three numbers and console logs the product
function multiplysThreeNums(num1,num2,num3){
  console.log(num1*num2*num3)
}
multiplysThreeNums(3,6,9)
//create a function that divides two numbers and returns the ???

function dividesTwoNumbers(num1,num2){
  return num1/num2
}
