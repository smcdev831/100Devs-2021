//Objects
//Please create a pokemon class with as much detail as possible in 10 minutes