//Create a dog object that has four properties and three methods
