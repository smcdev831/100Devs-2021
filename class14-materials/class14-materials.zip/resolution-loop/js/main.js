//Create a function that has a loop that prints your resolution 365 times to the console and then call that function

//Bonus can you make it print your resolution 365 times to the DOM?
