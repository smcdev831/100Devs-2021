//--- Easy
//create a variable and assign it a boolean

//create a variable and assign it a string that is a number

//add 10 to that number - how?!? https://media.giphy.com/media/lkdH8FmImcGoylv3t3/giphy.gif

//print that number to the console

//--- Medium
//create a variable that holds a value from the input

//add 21 to that number

//alert that number

//--- Hard
//create a variable that holds the h1

//add an event listener to that element that places the product of the two previous variables in the DOM
