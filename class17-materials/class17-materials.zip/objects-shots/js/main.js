//The user will enter a cocktail. Get a cocktail name, photo, and instructions and place them in the DOM
